<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\KartuKeluarga */
?>
<div class="kartu-keluarga-update">

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
