<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use kartik\widgets\Select2;
use app\models\Provinsi;
use app\models\Kabupaten;
use app\models\Kecamatan;
use app\models\Kelurahan;
use yii\web\JsExpression;

$url = \yii\helpers\Url::to(['city-list']);
// $cityDesc = empty($model->kelurahan) ? '' : Kelurahan::findOne($model->kelurahan)->description;


/* @var $this yii\web\View */
/* @var $model app\models\KartuKeluarga */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="kartu-keluarga-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'no_kk')->textInput(['maxlength' => true]) ?>

    <?php


    echo $form->field($model, 'id_kelurahan')->widget(Select2::classname(), [
        'initValueText' => '', // set the initial display text
        'options' => ['placeholder' => 'Search for a city ...'],
        'pluginOptions' => [
            'allowClear' => true,
            'minimumInputLength' => 3,
            'language' => [
                'errorLoading' => new JsExpression("function () { return 'Waiting for results...'; }"),
            ],
            'ajax' => [
                'url' => $url,
                'dataType' => 'json',
                'data' => new JsExpression('function(params) { return {q:params.term}; }')
            ],
            // 'escapeMarkup' => new JsExpression('function (markup) { return markup; }'),
            // 'templateResult' => new JsExpression('function(city) { return city.text; }'),
            // 'templateSelection' => new JsExpression('function (city) { return city.text; }'),
        ],
    ]);

    ?>

    <?= $form->field($model, 'rt')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'rw')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'nama_kepala_keluarga')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'alamat')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'kode_pos')->textInput(['maxlength' => true]) ?>

  
	<?php if (!Yii::$app->request->isAjax){ ?>
	  	<div class="form-group">
	        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
	    </div>
	<?php } ?>

    <?php ActiveForm::end(); ?>
    
</div>
