<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\SuratWarga */

?>
<div class="surat-warga-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
