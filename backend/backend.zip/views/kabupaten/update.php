<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Kabupaten */
?>
<div class="kabupaten-update">

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
