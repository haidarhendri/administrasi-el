<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\UserWarga */

?>
<div class="user-warga-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
