<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\EventMutasiKeluar */

?>
<div class="event-mutasi-keluar-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
