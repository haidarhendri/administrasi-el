<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\SuratKeluar */
?>
<div class="surat-keluar-update">

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
