<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\DetailAnggotaKeluarga */

?>
<div class="detail-anggota-keluarga-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
