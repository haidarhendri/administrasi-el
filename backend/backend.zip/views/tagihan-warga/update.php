<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\TagihanWarga */
?>
<div class="tagihan-warga-update">

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
