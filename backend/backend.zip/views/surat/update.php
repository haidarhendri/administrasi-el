<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Surat */
?>
<div class="surat-update">

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
